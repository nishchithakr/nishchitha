package com.capgemini.fms.repository;

import java.util.List;

import com.capgemini.fms.pojo.Actor;
import com.capgemini.fms.pojo.Film;

public interface IActorRepository {
	public Actor save(Actor actor);
	public List<Actor> searchActorByName(String name);
	public boolean remove(String name);
	public boolean updateActor(Actor actor);

}
