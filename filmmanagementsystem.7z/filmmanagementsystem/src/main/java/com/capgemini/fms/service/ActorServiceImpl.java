package com.capgemini.fms.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.capgemini.fms.pojo.Actor;
import com.capgemini.fms.pojo.Film;
import com.capgemini.fms.repository.IActorRepository;



public class ActorServiceImpl implements IActorService {

	private IActorRepository repo;
	public ActorServiceImpl(IActorRepository repo) {
		super();
		this.repo = repo;
	}

	public Actor addActor(Actor actor) 
	{
		Actor actor1 = new Actor();
		actor1=repo.save(actor);
		return actor1;
	}



		public List<Actor> findActorByName(String name) {
			if(name==null){
				throw new NullPointerException();
			}
			Actor actor2 = new Actor();
			List<Actor> actorList=new ArrayList<Actor>();
			actorList.add(actor2);
			actorList=repo.searchActorByName(name);
			if(actor2.getFirstName()!=name){
				throw new IllegalArgumentException();
			}
			return actorList;
		}
		public String removeActor(String name) {
			if(name.equals(null)){
				throw new NullPointerException();
			}
			else{
				try{
					if(repo.remove(name)){
						return "Actor is deleted";
					}
						else{
							return "Actor is not present";
						}
					}catch(Exception e){
						return "error";
					}
				}
		}

		public String modifyActor(Actor actor) {
			if(actor==null){
				throw new NullPointerException();
			}
			else{
				try{
					if(repo.updateActor(actor)){
						return "Actor is updated";
					}
					
				}catch(Exception e){
				
				}
				return "Actor is not updated";
			}
		}

		public List<Actor> searchActorByName(String name) {
			// TODO Auto-generated method stub
			return null;
		}


}
