package com.capgemini.fms.repository;

import java.util.Date;
import java.util.List;

import com.capgemini.fms.pojo.Film;

public interface IFilmRepository {
	public Film save(Film film);
	public List<Film> searchFilmByTitle(String title);
	public List<Film> searchFilmByLanguage(String language);
	public List<Film> searchFilmByRating(byte rating);
	public List<Film> searchFilmByReleaseYear(Date releaseyear);
	public  boolean remove(String title);
	public boolean updateFilm(Film film);
	
	}

