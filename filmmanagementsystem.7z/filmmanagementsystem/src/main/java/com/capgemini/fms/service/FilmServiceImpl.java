package com.capgemini.fms.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.capgemini.fms.pojo.Actor;
import com.capgemini.fms.pojo.Album;
import com.capgemini.fms.pojo.Category;
import com.capgemini.fms.pojo.Film;
import com.capgemini.fms.repository.IFilmRepository;

public class FilmServiceImpl implements IFilmService{

	private IFilmRepository repo;
	public FilmServiceImpl(IFilmRepository repo) {
		super();
		this.repo = repo;
	}

	public String addFilm(Film film) 
	{
		Film film1 = new Film();
		film1=repo.save(film);
		return "film added successfully";
	}

	public  List<Film> searchFilmByTitle(String title) {
		if(title==null){
			throw new NullPointerException();
		}
		Film film2 = new Film();
		List<Film> filmList=new ArrayList<Film>();
		filmList.add(film2);
		filmList=repo.searchFilmByTitle(title);
		if(film2.getTitle()!=title){
			throw new IllegalArgumentException();
		}
		return filmList;
	}
	
	
	public List<Film> searchFilmByLanguage(String language){
		if(language==null){
			throw new NullPointerException();
		}
		Film film3 = new Film();
		List<Film> filmListByLanguage=new ArrayList<Film>();
		filmListByLanguage.add(film3);
		filmListByLanguage=repo.searchFilmByLanguage(language);
		if(film3.getLanguage()!=language){
			throw new IllegalArgumentException();
		}
		return filmListByLanguage;
		
	}
	public List<Film> searchFilmByRating(byte rating){
		if(rating==0){
			throw new NullPointerException();
		}
		Film film4 = new Film();
		List<Film> filmListByRating=new ArrayList<Film>();
		filmListByRating.add(film4);
		filmListByRating=repo.searchFilmByRating(rating);
		if(film4.getRating()!=rating){
			throw new IllegalArgumentException();
		}
		return filmListByRating;
		
	}
	public List<Film> searchFilmByReleaseYear(Date releaseyear){
		if(releaseyear==null){
			throw new NullPointerException();
		}
		Film film5 = new Film();
		List<Film> filmListByReleaseYear=new ArrayList<Film>();
		filmListByReleaseYear.add(film5);
		filmListByReleaseYear=repo.searchFilmByReleaseYear(releaseyear);
		if(film5.getReleaseyear()!=releaseyear){
			throw new IllegalArgumentException();
		}
		return filmListByReleaseYear;
		
	}


	public String removeFilm(String title) {
		if(title.equals(null)){
			throw new NullPointerException();
		}
		else{
			try{
				if(repo.remove(title)){
					return "Film is removed";
				}
					else{
						return "film is not present";
					}
				}catch(Exception e){
					return "erroe";
				}
			}
			
		}
		public String modifyFilm(Film film){
			if(film==null){
				throw new NullPointerException();
			}
			else{
				try{
					if(repo.updateFilm(film)){
						return "Film is updated";
					}
					
				}catch(Exception e){
				
				}
				return "Film is not updated";
			}
		}

	

		

		public List<Film> getAllFilm() {
			
			return null;
		}

		
		
	}



