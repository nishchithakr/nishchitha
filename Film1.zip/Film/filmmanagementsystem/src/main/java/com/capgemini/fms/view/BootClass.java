package com.capgemini.fms.view;

import java.util.Scanner;

public class BootClass {

	public static void main(String[] args) {
		
		menuSelection();

		}

	private static void menuSelection() {
		
		Scanner sc = new Scanner(System.in);
		int option;
		String choice = null;
		
	}

	}


