helloApp.controller('namaskar',function($scope)
{
    $scope.upVoteCount=function (blog) {
        blog.voteCount++;
    }
    $scope.blogs=[
        {
            title:'The Home and the World',
            author:"Rabindranath Tagore",
            image:'../Images/img3.jpg',
            summary:'The Home and the World (in the original Bengali, ঘরে বাইরে Ghôre Baire, lit. "At home and outside") is a 1916 novel by Rabindranath Tagore. The book illustrates the battle Tagore had with himself, between the ideas of Western culture and revolution against the Western culture.',
            date:new Date('14/06/2016'),
            voteCount:20
        },
        {
            title:'Jasmine',
            author:"Bharathi Mukherjee",
            image:'../Images/img1.jpg',
            summary:'Jasmine is a novel of emigration and assimilation, both on physical and psychological levels. In this novel, Bharati Mukherjee fictionalizes the process of Americanization by tracing a young Indian woman’s experiences of trauma and triumph in her attempt to forge a new identity for herself.',
            date:new Date('14/06/2016'),
            voteCount:15
        },
        {
            title:'A Fine Balance',
            author:"Rohinton Mistry",
            image:'../Images/img2.jpg',
            summary:'A Fine Balance is the second novel by Rohinton Mistry. Set in "an unidentified city" in India, initially in 1975 and later in 1984 during the turmoil of The Emergency.[2] The book concerns four characters from varied backgrounds – Dina Dalal, Ishvar Darji, his nephew Omprakash Darji and the young student Maneck Kohlah',
            date:new Date('14/06/2016'),
            voteCount:30
        },
        {
            title:'The Hungry Tide',
            author:"Amitav Ghosh",
            image:'../Images/img4.jpg',
            summary:'The Hungry Tide tells a very noncontemporary story of adventure and unlikely love, identity and history, set in one of the most fascinating regions on the earth. Off the easternmost coast of India, in the Bay of Bengal, lies the immense labyrinth of tiny islands known as the Sundarbans.',
            date:new Date('14/06/2016'),
            voteCount:13
        }

    ]


})